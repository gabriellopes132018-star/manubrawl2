<?php
class Client {
    private $conn;
    private $table = 'clients';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function create($name, $cpf, $email, $phone, $address, $city, $state, $postal_code) {
        $cpf_clean = preg_replace('/[^0-9]/', '', $cpf);
        
        $stmt = $this->conn->prepare("SELECT id FROM {$this->table} WHERE cpf = :cpf");
        $stmt->execute(['cpf' => $cpf_clean]);
        if ($stmt->fetch()) {
            return 'cpf_duplicado';
        }
        
        if (!empty($email)) {
            $stmt = $this->conn->prepare("SELECT id FROM {$this->table} WHERE email = :email");
            $stmt->execute(['email' => $email]);
            if ($stmt->fetch()) {
                return 'email_duplicado';
            }
        }
        
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (name, cpf, email, phone, address, city, state, postal_code) VALUES (:name, :cpf, :email, :phone, :address, :city, :state, :postal_code)");
        
        if ($stmt->execute([
            'name' => $name,
            'cpf' => $cpf_clean,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'postal_code' => $postal_code
        ])) {
            return true;
        }
        
        return false;
    }
    
    public function update($id, $name, $cpf, $email, $phone, $address, $city, $state, $postal_code) {
        $cpf_clean = preg_replace('/[^0-9]/', '', $cpf);
        
        $stmt = $this->conn->prepare("SELECT id FROM {$this->table} WHERE cpf = :cpf AND id != :id");
        $stmt->execute(['cpf' => $cpf_clean, 'id' => $id]);
        if ($stmt->fetch()) {
            return 'cpf_duplicado';
        }
        
        if (!empty($email)) {
            $stmt = $this->conn->prepare("SELECT id FROM {$this->table} WHERE email = :email AND id != :id");
            $stmt->execute(['email' => $email, 'id' => $id]);
            if ($stmt->fetch()) {
                return 'email_duplicado';
            }
        }
        
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET name = :name, cpf = :cpf, email = :email, phone = :phone, address = :address, city = :city, state = :state, postal_code = :postal_code WHERE id = :id");
        
        if ($stmt->execute([
            'name' => $name,
            'cpf' => $cpf_clean,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'postal_code' => $postal_code,
            'id' => $id
        ])) {
            return true;
        }
        
        return false;
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY name ASC");
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
}
?>
