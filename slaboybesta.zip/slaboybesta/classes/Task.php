<?php
class Task {
    private $conn;
    private $table = 'tasks';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function create($title, $description, $type, $priority, $assigned_to, $assigned_by, $due_date, $notes = '') {
        try {
            // Verificar permissões hierárquicas
            if (!$this->canAssignTask($assigned_by, $assigned_to)) {
                return 'permission_denied';
            }
            
            $stmt = $this->conn->prepare("
                INSERT INTO {$this->table} 
                (title, description, type, priority, assigned_to, assigned_by, due_date, notes) 
                VALUES (:title, :description, :type, :priority, :assigned_to, :assigned_by, :due_date, :notes)
            ");
            
            $stmt->execute([
                'title' => $title,
                'description' => $description,
                'type' => $type,
                'priority' => $priority,
                'assigned_to' => $assigned_to,
                'assigned_by' => $assigned_by,
                'due_date' => $due_date,
                'notes' => $notes
            ]);
            
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function update($id, $title, $description, $type, $priority, $assigned_to, $due_date, $notes, $user_id, $user_role) {
        try {
            if (!$this->canManageTask($id, $user_id, $user_role)) {
                return 'permission_denied';
            }
            
            // Verificar se está tentando reatribuir a tarefa
            $current_task = $this->getById($id);
            if ($current_task && $current_task['assigned_to'] != $assigned_to) {
                // Se está mudando a atribuição, verificar hierarquia
                if (!$this->canAssignTask($user_id, $assigned_to)) {
                    return 'permission_denied';
                }
            }
            
            $stmt = $this->conn->prepare("
                UPDATE {$this->table} 
                SET title = :title, description = :description, type = :type, 
                    priority = :priority, assigned_to = :assigned_to, due_date = :due_date, notes = :notes
                WHERE id = :id
            ");
            
            return $stmt->execute([
                'id' => $id,
                'title' => $title,
                'description' => $description,
                'type' => $type,
                'priority' => $priority,
                'assigned_to' => $assigned_to,
                'due_date' => $due_date,
                'notes' => $notes
            ]);
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function updateStatus($id, $status, $user_id, $user_role) {
        try {
            if (!$this->canUpdateStatus($id, $user_id, $user_role)) {
                return 'permission_denied';
            }
            
            $completed_at = $status === 'completed' ? date('Y-m-d H:i:s') : null;
            
            $stmt = $this->conn->prepare("
                UPDATE {$this->table} 
                SET status = :status, completed_at = :completed_at
                WHERE id = :id
            ");
            
            return $stmt->execute([
                'id' => $id,
                'status' => $status,
                'completed_at' => $completed_at
            ]);
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function delete($id, $user_id, $user_role) {
        try {
            if (!$this->canManageTask($id, $user_id, $user_role)) {
                return 'permission_denied';
            }
            
            // Deletar comentários primeiro
            $stmt = $this->conn->prepare("DELETE FROM task_comments WHERE task_id = :id");
            $stmt->execute(['id' => $id]);
            
            // Deletar tarefa
            $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
            return $stmt->execute(['id' => $id]);
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("
            SELECT t.*, 
                   u1.name as assigned_to_name, u1.role as assigned_to_role,
                   u2.name as assigned_by_name, u2.role as assigned_by_role
            FROM {$this->table} t
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            WHERE t.id = :id
            LIMIT 1
        ");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
    
    public function getAll($user_id = null, $role = null) {
        $query = "
            SELECT t.*, 
                   u1.name as assigned_to_name, u1.role as assigned_to_role,
                   u2.name as assigned_by_name, u2.role as assigned_by_role
            FROM {$this->table} t
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
        ";
        
        if ($user_id && $role !== 'admin') {
            $query .= " WHERE (t.assigned_to = :user_id OR t.assigned_by = :user_id)";
        }
        
        $query .= " ORDER BY 
            CASE t.status 
                WHEN 'pending' THEN 1 
                WHEN 'in_progress' THEN 2 
                WHEN 'completed' THEN 3 
                WHEN 'cancelled' THEN 4 
            END,
            CASE t.priority 
                WHEN 'urgent' THEN 1 
                WHEN 'high' THEN 2 
                WHEN 'medium' THEN 3 
                WHEN 'low' THEN 4 
            END,
            t.due_date ASC
        ";
        
        $stmt = $this->conn->prepare($query);
        
        if ($user_id && $role !== 'admin') {
            $stmt->execute(['user_id' => $user_id]);
        } else {
            $stmt->execute();
        }
        
        return $stmt->fetchAll();
    }
    
    public function getMyTasks($user_id) {
        $stmt = $this->conn->prepare("
            SELECT t.*, 
                   u1.name as assigned_to_name, u1.role as assigned_to_role,
                   u2.name as assigned_by_name, u2.role as assigned_by_role
            FROM {$this->table} t
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            WHERE t.assigned_to = :user_id
            ORDER BY 
                CASE t.status 
                    WHEN 'pending' THEN 1 
                    WHEN 'in_progress' THEN 2 
                    WHEN 'completed' THEN 3 
                    WHEN 'cancelled' THEN 4 
                END,
                CASE t.priority 
                    WHEN 'urgent' THEN 1 
                    WHEN 'high' THEN 2 
                    WHEN 'medium' THEN 3 
                    WHEN 'low' THEN 4 
                END,
                t.due_date ASC
        ");
        $stmt->execute(['user_id' => $user_id]);
        return $stmt->fetchAll();
    }
    
    public function getTasksByDate($date, $user_id = null, $role = null) {
        $query = "
            SELECT t.*, 
                   u1.name as assigned_to_name, u1.role as assigned_to_role,
                   u2.name as assigned_by_name, u2.role as assigned_by_role
            FROM {$this->table} t
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            WHERE DATE(t.due_date) = :date
        ";
        
        if ($user_id && $role !== 'admin') {
            $query .= " AND (t.assigned_to = :user_id OR t.assigned_by = :user_id)";
        }
        
        $query .= " ORDER BY t.due_date ASC";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['date' => $date];
        if ($user_id && $role !== 'admin') {
            $params['user_id'] = $user_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function getPendingReminders() {
        $stmt = $this->conn->query("
            SELECT t.*, 
                   u1.name as assigned_to_name, u1.email as assigned_to_email,
                   u2.name as assigned_by_name
            FROM {$this->table} t
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            WHERE t.status IN ('pending', 'in_progress')
              AND t.reminder_sent = 0
              AND t.due_date <= DATE_ADD(NOW(), INTERVAL 24 HOUR)
              AND t.due_date >= NOW()
        ");
        return $stmt->fetchAll();
    }
    
    public function markReminderSent($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET reminder_sent = 1 WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    public function getUpcomingTasks($user_id, $days = 7) {
        $stmt = $this->conn->prepare("
            SELECT t.*, 
                   u1.name as assigned_to_name,
                   u2.name as assigned_by_name
            FROM {$this->table} t
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            WHERE t.assigned_to = :user_id
              AND t.status IN ('pending', 'in_progress')
              AND t.due_date <= DATE_ADD(NOW(), INTERVAL :days DAY)
            ORDER BY t.due_date ASC
            LIMIT 5
        ");
        $stmt->execute(['user_id' => $user_id, 'days' => $days]);
        return $stmt->fetchAll();
    }
    
    public function getTaskStats($user_id = null, $role = null) {
        $where = '';
        $params = [];
        
        if ($user_id && $role !== 'admin') {
            $where = " WHERE (assigned_to = :user_id OR assigned_by = :user_id)";
            $params['user_id'] = $user_id;
        }
        
        $stmt = $this->conn->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status IN ('pending', 'in_progress') AND due_date < NOW() THEN 1 ELSE 0 END) as overdue
            FROM {$this->table}
            {$where}
        ");
        $stmt->execute($params);
        return $stmt->fetch();
    }
    
    public function canManageTask($task_id, $user_id, $user_role) {
        // Admin pode gerenciar qualquer tarefa
        if ($user_role === 'admin') {
            return true;
        }
        
        // Buscar tarefa
        $task = $this->getById($task_id);
        if (!$task) {
            return false;
        }
        
        // Apenas o criador da tarefa pode editar/excluir (exceto admin)
        return $task['assigned_by'] == $user_id;
    }
    
    public function canUpdateStatus($task_id, $user_id, $user_role) {
        // Admin pode atualizar qualquer status
        if ($user_role === 'admin') {
            return true;
        }
        
        // Buscar tarefa
        $task = $this->getById($task_id);
        if (!$task) {
            return false;
        }
        
        // O responsável pela tarefa pode atualizar o status
        // Ou quem criou a tarefa
        return $task['assigned_to'] == $user_id || $task['assigned_by'] == $user_id;
    }
    
    public function canViewTask($task_id, $user_id, $user_role) {
        // Admin pode ver qualquer tarefa
        if ($user_role === 'admin') {
            return true;
        }
        
        // Buscar tarefa
        $task = $this->getById($task_id);
        if (!$task) {
            return false;
        }
        
        // Pode ver se foi atribuído a ele ou se ele criou
        return $task['assigned_to'] == $user_id || $task['assigned_by'] == $user_id;
    }
    
    private function canAssignTask($assigned_by_id, $assigned_to_id) {
        // Pegar roles dos usuários
        $stmt = $this->conn->prepare("SELECT role FROM users WHERE id = :id");
        
        $stmt->execute(['id' => $assigned_by_id]);
        $assigner = $stmt->fetch();
        
        $stmt->execute(['id' => $assigned_to_id]);
        $assignee = $stmt->fetch();
        
        if (!$assigner || !$assignee) {
            return false;
        }
        
        $assigner_role = $assigner['role'];
        $assignee_role = $assignee['role'];
        
        // Admin pode atribuir para qualquer um
        if ($assigner_role === 'admin') {
            return true;
        }
        
        // Gerente pode atribuir apenas para vendedor
        if ($assigner_role === 'manager' && $assignee_role === 'seller') {
            return true;
        }
        
        // Vendedor não pode atribuir tarefas
        return false;
    }
    
    public function addComment($task_id, $user_id, $comment, $user_role) {
        try {
            if (!$this->canViewTask($task_id, $user_id, $user_role)) {
                return 'permission_denied';
            }
            
            $stmt = $this->conn->prepare("
                INSERT INTO task_comments (task_id, user_id, comment) 
                VALUES (:task_id, :user_id, :comment)
            ");
            
            return $stmt->execute([
                'task_id' => $task_id,
                'user_id' => $user_id,
                'comment' => $comment
            ]);
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function getComments($task_id) {
        $stmt = $this->conn->prepare("
            SELECT tc.*, u.name as user_name, u.role
            FROM task_comments tc
            LEFT JOIN users u ON tc.user_id = u.id
            WHERE tc.task_id = :task_id
            ORDER BY tc.created_at ASC
        ");
        $stmt->execute(['task_id' => $task_id]);
        return $stmt->fetchAll();
    }
    
    public function getAssignableUsers($assigner_role) {
        if ($assigner_role === 'admin') {
            // Admin pode atribuir para gerente e vendedor
            $stmt = $this->conn->query("
                SELECT id, name, role 
                FROM users 
                WHERE role IN ('manager', 'seller')
                ORDER BY role, name
            ");
        } elseif ($assigner_role === 'manager') {
            // Gerente pode atribuir apenas para vendedor
            $stmt = $this->conn->query("
                SELECT id, name, role 
                FROM users 
                WHERE role = 'seller'
                ORDER BY name
            ");
        } else {
            // Vendedor não pode atribuir
            return [];
        }
        
        return $stmt->fetchAll();
    }
}
