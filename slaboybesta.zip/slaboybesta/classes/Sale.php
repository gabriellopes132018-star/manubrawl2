<?php
class Sale {
    private $conn;
    private $table = 'sales';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function create($client_id, $user_id, $payment_method, $notes, $items) {
        try {
            $this->conn->beginTransaction();
            
            $total = 0;
            foreach ($items as $item) {
                $total += $item['subtotal'];
            }
            
            $stmt = $this->conn->prepare("INSERT INTO {$this->table} (client_id, user_id, total, payment_method, notes, status) VALUES (:client_id, :user_id, :total, :payment_method, :notes, 'concluída')");
            
            $stmt->execute([
                'client_id' => $client_id ?: null,
                'user_id' => $user_id,
                'total' => $total,
                'payment_method' => $payment_method,
                'notes' => $notes
            ]);
            
            $sale_id = $this->conn->lastInsertId();
            
            foreach ($items as $item) {
                $stmt = $this->conn->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price, subtotal) VALUES (:sale_id, :product_id, :quantity, :price, :subtotal)");
                
                $stmt->execute([
                    'sale_id' => $sale_id,
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                    'subtotal' => $item['subtotal']
                ]);
                
                $stmt = $this->conn->prepare("UPDATE products SET stock = stock - :quantity WHERE id = :id");
                $stmt->execute(['quantity' => $item['quantity'], 'id' => $item['product_id']]);
            }
            
            $this->conn->commit();
            return $sale_id;
            
        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }
    
    public function delete($id) {
        try {
            $this->conn->beginTransaction();
            
            $sale = $this->getById($id);
            if (!$sale) {
                $this->conn->rollBack();
                return false;
            }
            
            foreach ($sale['items'] as $item) {
                $stmt = $this->conn->prepare("UPDATE products SET stock = stock + :quantity WHERE id = :id");
                $stmt->execute(['quantity' => $item['quantity'], 'id' => $item['product_id']]);
            }
            
            $stmt = $this->conn->prepare("DELETE FROM sale_items WHERE sale_id = :id");
            $stmt->execute(['id' => $id]);
            
            $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
            $stmt->execute(['id' => $id]);
            
            $this->conn->commit();
            return true;
            
        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT s.*, c.name as client_name, u.name as user_name FROM {$this->table} s LEFT JOIN clients c ON s.client_id = c.id LEFT JOIN users u ON s.user_id = u.id ORDER BY s.sale_date DESC");
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT s.*, c.name as client_name, u.name as user_name FROM {$this->table} s LEFT JOIN clients c ON s.client_id = c.id LEFT JOIN users u ON s.user_id = u.id WHERE s.id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        $sale = $stmt->fetch();
        
        if ($sale) {
            $stmt = $this->conn->prepare("SELECT si.*, p.name as product_name FROM sale_items si JOIN products p ON si.product_id = p.id WHERE si.sale_id = :sale_id");
            $stmt->execute(['sale_id' => $id]);
            $sale['items'] = $stmt->fetchAll();
        }
        
        return $sale;
    }
    
    public function getRecentSales($limit = 5) {
        $stmt = $this->conn->prepare("SELECT s.*, c.name as client_name, u.name as user_name FROM {$this->table} s LEFT JOIN clients c ON s.client_id = c.id LEFT JOIN users u ON s.user_id = u.id ORDER BY s.sale_date DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getSalesReport($start_date, $end_date) {
        $stmt = $this->conn->prepare("SELECT COALESCE(SUM(total), 0) as total_sales, COUNT(*) as num_sales, COALESCE(AVG(total), 0) as avg_ticket FROM {$this->table} WHERE sale_date BETWEEN :start_date AND :end_date AND status = 'concluída'");
        $stmt->execute(['start_date' => $start_date, 'end_date' => $end_date . ' 23:59:59']);
        return $stmt->fetch();
    }
    
    public function getTopProducts($limit = 10, $start_date = null, $end_date = null) {
        if ($start_date && $end_date) {
            $stmt = $this->conn->prepare("SELECT p.name, SUM(si.quantity) as total_sold, SUM(si.subtotal) as revenue FROM sale_items si JOIN products p ON si.product_id = p.id JOIN {$this->table} s ON si.sale_id = s.id WHERE s.sale_date BETWEEN :start_date AND :end_date AND s.status = 'concluída' GROUP BY p.id, p.name ORDER BY total_sold DESC LIMIT :limit");
            $stmt->bindValue(':start_date', $start_date);
            $stmt->bindValue(':end_date', $end_date . ' 23:59:59');
        } else {
            $stmt = $this->conn->prepare("SELECT p.name, SUM(si.quantity) as total_sold, SUM(si.subtotal) as revenue FROM sale_items si JOIN products p ON si.product_id = p.id JOIN {$this->table} s ON si.sale_id = s.id WHERE s.status = 'concluída' GROUP BY p.id, p.name ORDER BY total_sold DESC LIMIT :limit");
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getTopClients($limit = 10, $start_date = null, $end_date = null) {
        if ($start_date && $end_date) {
            $stmt = $this->conn->prepare("SELECT c.name as client_name, COUNT(s.id) as num_purchases, SUM(s.total) as total_spent FROM {$this->table} s LEFT JOIN clients c ON s.client_id = c.id WHERE s.sale_date BETWEEN :start_date AND :end_date AND s.status = 'concluída' AND s.client_id IS NOT NULL GROUP BY c.id, c.name ORDER BY total_spent DESC LIMIT :limit");
            $stmt->bindValue(':start_date', $start_date);
            $stmt->bindValue(':end_date', $end_date . ' 23:59:59');
        } else {
            $stmt = $this->conn->prepare("SELECT c.name as client_name, COUNT(s.id) as num_purchases, SUM(s.total) as total_spent FROM {$this->table} s LEFT JOIN clients c ON s.client_id = c.id WHERE s.status = 'concluída' AND s.client_id IS NOT NULL GROUP BY c.id, c.name ORDER BY total_spent DESC LIMIT :limit");
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getSalesByPaymentMethod($start_date = null, $end_date = null) {
        if ($start_date && $end_date) {
            $stmt = $this->conn->prepare("SELECT payment_method, COUNT(*) as count, SUM(total) as total FROM {$this->table} WHERE sale_date BETWEEN :start_date AND :end_date AND status = 'concluída' GROUP BY payment_method ORDER BY total DESC");
            $stmt->execute(['start_date' => $start_date, 'end_date' => $end_date . ' 23:59:59']);
        } else {
            $stmt = $this->conn->query("SELECT payment_method, COUNT(*) as count, SUM(total) as total FROM {$this->table} WHERE status = 'concluída' GROUP BY payment_method ORDER BY total DESC");
        }
        return $stmt->fetchAll();
    }
    
    public function getDailySales($start_date, $end_date) {
        $stmt = $this->conn->prepare("SELECT DATE(sale_date) as date, SUM(total) as total FROM {$this->table} WHERE sale_date BETWEEN :start_date AND :end_date AND status = 'concluída' GROUP BY DATE(sale_date) ORDER BY date ASC");
        $stmt->execute(['start_date' => $start_date, 'end_date' => $end_date . ' 23:59:59']);
        return $stmt->fetchAll();
    }
}
?>
