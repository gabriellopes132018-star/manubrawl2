-- ================================================
-- DIAMOND SYSTEM - MÓDULO DE AGENDA E TAREFAS
-- Execute este script para adicionar as tabelas
-- ================================================

USE `diamond_system`;

-- ================================================
-- TABELA DE TAREFAS
-- ================================================
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `type` enum('task','meeting','appointment') NOT NULL DEFAULT 'task',
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `status` enum('pending','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
  `assigned_to` int(11) NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `due_date` datetime NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  `reminder_sent` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `assigned_by` (`assigned_by`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- TABELA DE COMENTÁRIOS DE TAREFAS
-- ================================================
CREATE TABLE IF NOT EXISTS `task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `task_comments_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `task_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- INSERIR DADOS DE EXEMPLO
-- ================================================

-- Tarefa de exemplo (admin para gerente)
INSERT INTO `tasks` (`title`, `description`, `type`, `priority`, `status`, `assigned_to`, `assigned_by`, `due_date`) 
SELECT 
  'Revisar estoque de produtos premium',
  'Verificar e atualizar o estoque de todos os produtos de alto valor',
  'task',
  'high',
  'pending',
  2,
  1,
  DATE_ADD(NOW(), INTERVAL 2 DAY)
FROM users WHERE id = 1 AND id = 2 LIMIT 1;

-- Compromisso de exemplo
INSERT INTO `tasks` (`title`, `description`, `type`, `priority`, `status`, `assigned_to`, `assigned_by`, `due_date`)
SELECT
  'Reunião com fornecedores',
  'Negociação de novos produtos para o próximo trimestre',
  'meeting',
  'medium',
  'pending',
  1,
  1,
  DATE_ADD(NOW(), INTERVAL 3 DAY)
FROM users WHERE id = 1 LIMIT 1;

-- ================================================
-- FIM DO SCRIPT
-- ================================================
