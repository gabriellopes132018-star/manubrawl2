# 🚀 Guia de Instalação - Diamond System no XAMPP

## 📋 Pré-requisitos

Antes de começar, certifique-se de ter:
- ✅ XAMPP instalado (PHP 8.0+, MySQL 5.7+, Apache)
- ✅ Navegador web moderno
- ✅ Acesso de administrador no computador

---

## 📥 Passo 1: Copiar Arquivos

1. Localize a pasta `diamond_system` com todos os arquivos
2. Copie TODA a pasta para dentro de `htdocs`:

```
C:\xampp\htdocs\diamond_system\
```

**Estrutura esperada:**
```
C:\xampp\htdocs\diamond_system\
├── assets/
├── classes/
├── config/
├── includes/
├── index.php
├── login.php
├── database.sql
└── ... (outros arquivos)
```

---

## 🗄️ Passo 2: Criar Banco de Dados

### 2.1 Iniciar Serviços do XAMPP
1. Abra o **XAMPP Control Panel**
2. Clique em **Start** ao lado de **Apache**
3. Clique em **Start** ao lado de **MySQL**

### 2.2 Acessar phpMyAdmin
1. Abra o navegador
2. Acesse: `http://localhost/phpmyadmin`

### 2.3 Criar o Banco
1. Clique em **New** (Novo) no menu lateral
2. Nome do banco: `diamond_system`
3. Collation: `utf8mb4_unicode_ci`
4. Clique em **Create**

### 2.4 Importar Tabelas
1. Selecione o banco `diamond_system` criado
2. Clique na aba **Import** (Importar)
3. Clique em **Choose File** (Escolher arquivo)
4. Selecione o arquivo `database.sql` da pasta do sistema
5. Clique em **Go** (Executar)
6. Aguarde a mensagem de sucesso

### 2.5 Importar Tabela de Tarefas (Opcional)
1. Ainda na aba **Import**
2. Selecione o arquivo `database_tasks.sql`
3. Clique em **Go**

---

## ⚙️ Passo 3: Configurar o Sistema

### 3.1 Abrir Arquivo de Configuração
Abra o arquivo: `C:\xampp\htdocs\diamond_system\config\config.php`

### 3.2 Verificar Configurações do Banco
```php
define('DB_HOST', 'localhost');      // Host do MySQL
define('DB_USER', 'root');           // Usuário do MySQL
define('DB_PASS', '');               // Senha (vazia por padrão no XAMPP)
define('DB_NAME', 'diamond_system'); // Nome do banco
```

### 3.3 Verificar BASE_URL
```php
define('BASE_URL', '/diamond_system/');
```

**⚠️ IMPORTANTE:** Se você colocou em outra pasta, ajuste o caminho:
- Se em `C:\xampp\htdocs\loja\` → `define('BASE_URL', '/loja/');`
- Se direto em `htdocs` → `define('BASE_URL', '/');`

---

## 🔐 Passo 4: Acessar o Sistema

### 4.1 Abrir no Navegador
```
http://localhost/diamond_system/
```

### 4.2 Fazer Login
```
Usuário: admin
Senha: admin123
```

### 4.3 Alterar Senha (OBRIGATÓRIO)
Na primeira vez que entrar:
1. O sistema vai pedir para alterar a senha
2. Digite uma senha forte
3. Confirme a nova senha
4. Clique em **Salvar**

---

## ✅ Passo 5: Verificar Instalação

### Teste estas funcionalidades:

#### 1. Dashboard
- ✅ Gráficos carregando
- ✅ Estatísticas aparecendo
- ✅ Sem erros no console (F12)

#### 2. Cadastro de Categoria
1. Vá em **Categorias**
2. Adicione: "Anéis de Ouro"
3. Verifique se salvou

#### 3. Cadastro de Produto
1. Vá em **Produtos**
2. Adicione um produto de teste
3. Faça upload de uma imagem
4. Verifique se salvou

#### 4. Cadastro de Cliente
1. Vá em **Clientes**
2. Adicione: Nome + CPF + Email
3. Teste a busca de CEP
4. Verifique validação de CPF

---

## 🔧 Solução de Problemas

### Erro: "Banco de dados não encontrado"
**Solução:**
1. Verifique se o MySQL está rodando no XAMPP
2. Confirme que criou o banco `diamond_system`
3. Verifique as credenciais em `config/config.php`

### Erro: "Access denied for user"
**Solução:**
1. Abra `config/config.php`
2. Verifique o usuário e senha do MySQL
3. Senha padrão do XAMPP é vazia (`''`)

### Erro: "Headers already sent"
**Solução:**
1. Abra os arquivos PHP com editor que não adicione BOM
2. Não deve ter espaços ou linhas antes de `<?php`

### Erro 404: "Página não encontrada"
**Solução:**
1. Verifique se Apache está rodando
2. Confirme o caminho correto em `BASE_URL`
3. Acesse: `http://localhost/diamond_system/` (com a barra final)

### Imagens não carregam
**Solução:**
1. Verifique permissões da pasta `assets/uploads/products/`
2. No Windows: clique direito → Propriedades → Segurança
3. Dê permissão de escrita para todos

---

## 📊 Estrutura de Pastas Importantes

```
diamond_system/
├── config/
│   └── config.php          ← Configurações principais
├── classes/
│   ├── User.php           ← Gerenciamento de usuários
│   ├── Client.php         ← Gerenciamento de clientes
│   ├── Product.php        ← Gerenciamento de produtos
│   └── Sale.php           ← Gerenciamento de vendas
├── assets/
│   ├── css/               ← Estilos
│   ├── js/                ← JavaScript
│   └── uploads/
│       └── products/      ← Imagens dos produtos (criar se não existir)
├── includes/
│   ├── header.php         ← Cabeçalho
│   ├── sidebar.php        ← Menu lateral
│   └── footer.php         ← Rodapé
└── database.sql           ← Script do banco
```

---

## 🎯 Próximos Passos

Após instalação bem-sucedida:

1. **Criar Usuários**
   - Vá em Usuários
   - Adicione gerentes e vendedores
   - Defina permissões adequadas

2. **Cadastrar Categorias**
   - Diamantes
   - Joias de Ouro
   - Joias de Prata
   - Relógios

3. **Adicionar Produtos**
   - Cadastre produtos com fotos
   - Defina preços e estoque
   - Organize por categoria

4. **Registrar Clientes**
   - Cadastre clientes frequentes
   - Valide CPF e email
   - Registre endereços

5. **Começar Vendas**
   - Realize vendas de teste
   - Teste diferentes formas de pagamento
   - Verifique atualização de estoque

---

## 📝 Credenciais Padrão

### Acesso Administrativo
```
URL: http://localhost/diamond_system/
Usuário: admin
Senha: admin123
```

### Banco de Dados
```
Host: localhost
Usuário: root
Senha: (vazia)
Banco: diamond_system
```

---

## ⚠️ Segurança

### Recomendações para Produção:

1. **Altere a senha do admin** ✅
2. **Configure senha do MySQL**
3. **Ative HTTPS** (SSL)
4. **Configure backup automático**
5. **Restrinja acesso ao phpMyAdmin**
6. **Desative display_errors em produção**

---

## 🆘 Suporte

Se encontrar problemas:

1. Verifique o arquivo `ERROS_CORRIGIDOS.md`
2. Consulte `README.md` para documentação técnica
3. Revise `LEIA_ME_PRIMEIRO.txt`

---

**✨ Instalação Completa! Sistema Pronto para Uso!**

*Desenvolvido com 💎 para joalherias de alto padrão*
