<?php
require_once 'config/config.php';
require_once 'classes/Task.php';

require_login();

$conn = db_connect();
$task = new Task($conn);

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;
$view = $_GET['view'] ?? 'my_tasks';

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Processar formulários
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($action == 'create') {
        $title = $_POST['title'] ?? '';
        $description = $_POST['description'] ?? '';
        $type = $_POST['type'] ?? 'task';
        $priority = $_POST['priority'] ?? 'medium';
        $assigned_to = $_POST['assigned_to'] ?? 0;
        $due_date = $_POST['due_date'] ?? '';
        $notes = $_POST['notes'] ?? '';
        
        $result = $task->create($title, $description, $type, $priority, $assigned_to, $user_id, $due_date, $notes);
        
        if ($result === true) {
            display_success('Tarefa criada com sucesso!');
            redirect(BASE_URL . 'tasks.php');
        } elseif ($result === 'permission_denied') {
            display_error('Você não tem permissão para atribuir tarefas a este usuário!');
            $action = 'create';
        } else {
            display_error('Erro ao criar tarefa.');
            $action = 'create';
        }
    } elseif ($action == 'edit' && $id > 0) {
        $title = $_POST['title'] ?? '';
        $description = $_POST['description'] ?? '';
        $type = $_POST['type'] ?? 'task';
        $priority = $_POST['priority'] ?? 'medium';
        $assigned_to = $_POST['assigned_to'] ?? 0;
        $due_date = $_POST['due_date'] ?? '';
        $notes = $_POST['notes'] ?? '';
        
        $result = $task->update($id, $title, $description, $type, $priority, $assigned_to, $due_date, $notes, $user_id, $user_role);
        
        if ($result === true) {
            display_success('Tarefa atualizada com sucesso!');
            redirect(BASE_URL . 'tasks.php');
        } elseif ($result === 'permission_denied') {
            display_error('Você não tem permissão para editar esta tarefa!');
            redirect(BASE_URL . 'tasks.php');
        } else {
            display_error('Erro ao atualizar tarefa.');
            $action = 'edit';
        }
    } elseif ($action == 'update_status' && $id > 0) {
        $status = $_POST['status'] ?? 'pending';
        
        $result = $task->updateStatus($id, $status, $user_id, $user_role);
        
        if ($result === true) {
            display_success('Status atualizado com sucesso!');
        } elseif ($result === 'permission_denied') {
            display_error('Você não tem permissão para atualizar esta tarefa!');
        } else {
            display_error('Erro ao atualizar status.');
        }
        redirect(BASE_URL . 'tasks.php');
    } elseif ($action == 'add_comment' && $id > 0) {
        $comment = $_POST['comment'] ?? '';
        
        $result = $task->addComment($id, $user_id, $comment, $user_role);
        
        if ($result === true) {
            display_success('Comentário adicionado!');
        } elseif ($result === 'permission_denied') {
            display_error('Você não tem permissão para comentar nesta tarefa!');
        } else {
            display_error('Erro ao adicionar comentário.');
        }
        redirect(BASE_URL . 'tasks.php?action=view&id=' . $id);
    }
}

if ($action == 'delete' && $id > 0) {
    $result = $task->delete($id, $user_id, $user_role);
    
    if ($result === true) {
        display_success('Tarefa excluída com sucesso!');
    } elseif ($result === 'permission_denied') {
        display_error('Você não tem permissão para excluir esta tarefa!');
    } else {
        display_error('Erro ao excluir tarefa.');
    }
    redirect(BASE_URL . 'tasks.php');
}

// Buscar dados
if ($view == 'my_tasks') {
    $tasks = $task->getMyTasks($user_id);
} elseif ($view == 'all_tasks') {
    $tasks = $task->getAll($user_id, $user_role);
} elseif ($view == 'calendar') {
    $date = $_GET['date'] ?? date('Y-m-d');
    $tasks = $task->getTasksByDate($date, $user_id, $user_role);
} else {
    $tasks = $task->getMyTasks($user_id);
}

$stats = $task->getTaskStats($user_id, $user_role);
$upcoming = $task->getUpcomingTasks($user_id);

$page_title = 'Agenda e Tarefas';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<style>
.task-card {
    border-left: 4px solid;
    transition: all 0.3s ease;
    background: linear-gradient(135deg, rgba(13, 19, 32, 0.95) 0%, rgba(7, 11, 20, 0.95) 100%);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(59, 130, 246, 0.2);
}

.task-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(59, 130, 246, 0.2);
}

.task-card.priority-urgent {
    border-left-color: #ef4444;
}

.task-card.priority-high {
    border-left-color: #f59e0b;
}

.task-card.priority-medium {
    border-left-color: #3b82f6;
}

.task-card.priority-low {
    border-left-color: #6b7280;
}

.task-badge {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    font-weight: 600;
}

.stats-card {
    background: linear-gradient(135deg, rgba(13, 19, 32, 0.95) 0%, rgba(7, 11, 20, 0.95) 100%);
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: 0.75rem;
    padding: 1.5rem;
    transition: all 0.3s ease;
}

.stats-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(59, 130, 246, 0.3);
}

.stats-icon {
    width: 50px;
    height: 50px;
    border-radius: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
}

.nav-tabs .nav-link {
    color: rgba(255, 255, 255, 0.7);
    border: none;
    border-bottom: 2px solid transparent;
    background: transparent;
}

.nav-tabs .nav-link:hover {
    color: #3b82f6;
    border-bottom-color: #3b82f6;
}

.nav-tabs .nav-link.active {
    color: #3b82f6;
    background: transparent;
    border-bottom-color: #3b82f6;
}

.calendar-day {
    min-height: 100px;
    border: 1px solid rgba(59, 130, 246, 0.2);
    padding: 0.5rem;
    cursor: pointer;
    transition: all 0.2s ease;
}

.calendar-day:hover {
    background: rgba(59, 130, 246, 0.1);
}

.calendar-day.today {
    background: rgba(59, 130, 246, 0.2);
    border-color: #3b82f6;
}

.task-mini {
    font-size: 0.7rem;
    padding: 2px 4px;
    border-radius: 3px;
    margin-bottom: 2px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
</style>

<?php if ($action == 'list'): ?>

<!-- Estatísticas -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon bg-primary bg-opacity-25">
                    <i class="fas fa-tasks text-primary"></i>
                </div>
                <div class="ms-3">
                    <h6 class="text-muted mb-1">Total de Tarefas</h6>
                    <h3 class="mb-0"><?php echo $stats['total'] ?? 0; ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon bg-warning bg-opacity-25">
                    <i class="fas fa-clock text-warning"></i>
                </div>
                <div class="ms-3">
                    <h6 class="text-muted mb-1">Pendentes</h6>
                    <h3 class="mb-0"><?php echo $stats['pending'] ?? 0; ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon bg-info bg-opacity-25">
                    <i class="fas fa-spinner text-info"></i>
                </div>
                <div class="ms-3">
                    <h6 class="text-muted mb-1">Em Progresso</h6>
                    <h3 class="mb-0"><?php echo $stats['in_progress'] ?? 0; ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon bg-danger bg-opacity-25">
                    <i class="fas fa-exclamation-triangle text-danger"></i>
                </div>
                <div class="ms-3">
                    <h6 class="text-muted mb-1">Atrasadas</h6>
                    <h3 class="mb-0"><?php echo $stats['overdue'] ?? 0; ?></h3>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Cabeçalho -->
<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-calendar-alt me-2"></i>Agenda e Tarefas</h1>
    <div class="btn-toolbar mb-2">
        <?php if ($user_role == 'admin' || $user_role == 'manager'): ?>
        <a href="?action=create" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Nova Tarefa
        </a>
        <?php endif; ?>
    </div>
</div>

<!-- Navegação por abas -->
<ul class="nav nav-tabs mb-4">
    <li class="nav-item">
        <a class="nav-link <?php echo $view == 'my_tasks' ? 'active' : ''; ?>" href="?view=my_tasks">
            <i class="fas fa-user me-1"></i> Minhas Tarefas
        </a>
    </li>
    <?php if ($user_role == 'admin' || $user_role == 'manager'): ?>
    <li class="nav-item">
        <a class="nav-link <?php echo $view == 'all_tasks' ? 'active' : ''; ?>" href="?view=all_tasks">
            <i class="fas fa-list me-1"></i> Todas as Tarefas
        </a>
    </li>
    <?php endif; ?>
    <li class="nav-item">
        <a class="nav-link <?php echo $view == 'calendar' ? 'active' : ''; ?>" href="?view=calendar">
            <i class="fas fa-calendar me-1"></i> Calendário
        </a>
    </li>
</ul>

<?php if ($view == 'calendar'): ?>
    <!-- Visualização de Calendário -->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title mb-4">
                <i class="fas fa-calendar-day me-2"></i>Calendário de Tarefas
            </h5>
            
            <div class="mb-3">
                <input type="date" class="form-control" id="calendar-date" value="<?php echo $date ?? date('Y-m-d'); ?>" onchange="window.location.href='?view=calendar&date=' + this.value">
            </div>
            
            <div class="table-responsive">
                <?php
                $current_date = $date ?? date('Y-m-d');
                $week_start = date('Y-m-d', strtotime('monday this week', strtotime($current_date)));
                ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <?php
                            $days = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
                            foreach ($days as $day) {
                                echo "<th class='text-center'>$day</th>";
                            }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php
                            for ($i = 0; $i < 7; $i++) {
                                $day_date = date('Y-m-d', strtotime("$week_start +$i days"));
                                $day_tasks = $task->getTasksByDate($day_date, $user_id, $user_role);
                                $is_today = $day_date == date('Y-m-d') ? 'today' : '';
                                
                                echo "<td class='calendar-day $is_today' onclick=\"window.location.href='?view=calendar&date=$day_date'\">";
                                echo "<div class='fw-bold mb-2'>" . date('d/m', strtotime($day_date)) . "</div>";
                                
                                foreach ($day_tasks as $t) {
                                    $priority_class = 'bg-secondary';
                                    if ($t['priority'] == 'urgent') $priority_class = 'bg-danger';
                                    elseif ($t['priority'] == 'high') $priority_class = 'bg-warning';
                                    elseif ($t['priority'] == 'medium') $priority_class = 'bg-primary';
                                    
                                    echo "<div class='task-mini $priority_class bg-opacity-75 text-white'>" . htmlspecialchars($t['title']) . "</div>";
                                }
                                echo "</td>";
                            }
                            ?>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <?php if (!empty($tasks)): ?>
            <h6 class="mt-4 mb-3">Tarefas do dia <?php echo date('d/m/Y', strtotime($date)); ?></h6>
            <div class="row">
                <?php foreach ($tasks as $t): ?>
                <div class="col-md-6 mb-3">
                    <?php include 'includes/task_card.php'; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="alert alert-info mt-4">
                <i class="fas fa-info-circle me-2"></i>Nenhuma tarefa para esta data.
            </div>
            <?php endif; ?>
        </div>
    </div>

<?php else: ?>
    <!-- Visualização de Lista -->
    <div class="row">
        <?php if (empty($tasks)): ?>
        <div class="col-12">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                <?php echo $view == 'my_tasks' ? 'Você não tem tarefas atribuídas.' : 'Nenhuma tarefa encontrada.'; ?>
            </div>
        </div>
        <?php else: ?>
        <?php foreach ($tasks as $t): ?>
        <div class="col-md-6 mb-3">
            <?php include 'includes/task_card.php'; ?>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php elseif ($action == 'create' || $action == 'edit'): ?>
<?php
$current_task = null;
if ($action == 'edit' && $id > 0) {
    $current_task = $task->getById($id);
    if (!$current_task) {
        display_error('Tarefa não encontrada.');
        redirect(BASE_URL . 'tasks.php');
    }
    
    // Verificar permissão para editar
    if (!$task->canManageTask($id, $user_id, $user_role)) {
        display_error('Você não tem permissão para editar esta tarefa!');
        redirect(BASE_URL . 'tasks.php');
    }
}

$assignable_users = $task->getAssignableUsers($user_role);
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo $action == 'create' ? 'Nova Tarefa' : 'Editar Tarefa'; ?></h1>
    <div class="btn-toolbar mb-2">
        <a href="tasks.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<form method="post">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card mb-4">
                <div class="card-header">Informações da Tarefa</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Título *</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($current_task['title'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Descrição</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($current_task['description'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="type" class="form-label">Tipo *</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="task" <?php echo ($current_task['type'] ?? '') == 'task' ? 'selected' : ''; ?>>Tarefa</option>
                                <option value="meeting" <?php echo ($current_task['type'] ?? '') == 'meeting' ? 'selected' : ''; ?>>Reunião</option>
                                <option value="appointment" <?php echo ($current_task['type'] ?? '') == 'appointment' ? 'selected' : ''; ?>>Compromisso</option>
                            </select>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="priority" class="form-label">Prioridade *</label>
                            <select class="form-select" id="priority" name="priority" required>
                                <option value="low" <?php echo ($current_task['priority'] ?? '') == 'low' ? 'selected' : ''; ?>>Baixa</option>
                                <option value="medium" <?php echo ($current_task['priority'] ?? 'medium') == 'medium' ? 'selected' : ''; ?>>Média</option>
                                <option value="high" <?php echo ($current_task['priority'] ?? '') == 'high' ? 'selected' : ''; ?>>Alta</option>
                                <option value="urgent" <?php echo ($current_task['priority'] ?? '') == 'urgent' ? 'selected' : ''; ?>>Urgente</option>
                            </select>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="assigned_to" class="form-label">Atribuir Para *</label>
                            <select class="form-select" id="assigned_to" name="assigned_to" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($assignable_users as $user): ?>
                                <option value="<?php echo $user['id']; ?>" <?php echo ($current_task['assigned_to'] ?? '') == $user['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($user['name']); ?> 
                                    (<?php echo $user['role'] == 'manager' ? 'Gerente' : 'Vendedor'; ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="due_date" class="form-label">Data e Hora de Vencimento *</label>
                        <input type="datetime-local" class="form-control" id="due_date" name="due_date" 
                               value="<?php echo isset($current_task['due_date']) ? date('Y-m-d\TH:i', strtotime($current_task['due_date'])) : ''; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">Observações</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3"><?php echo htmlspecialchars($current_task['notes'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i>Salvar Tarefa
                </button>
            </div>
        </div>
    </div>
</form>

<?php elseif ($action == 'view' && $id > 0): ?>
<?php
$current_task = $task->getById($id);
if (!$current_task) {
    display_error('Tarefa não encontrada.');
    redirect(BASE_URL . 'tasks.php');
}

// Verificar permissão para visualizar
if (!$task->canViewTask($id, $user_id, $user_role)) {
    display_error('Você não tem permissão para visualizar esta tarefa!');
    redirect(BASE_URL . 'tasks.php');
}

$comments = $task->getComments($id);
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detalhes da Tarefa</h1>
    <div class="btn-toolbar mb-2">
        <a href="tasks.php" class="btn btn-secondary me-2">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
        <?php if ($user_id == $current_task['assigned_by'] || $user_role == 'admin'): ?>
        <a href="?action=edit&id=<?php echo $id; ?>" class="btn btn-primary me-2">
            <i class="fas fa-edit me-1"></i> Editar
        </a>
        <a href="?action=delete&id=<?php echo $id; ?>" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja excluir esta tarefa?')">
            <i class="fas fa-trash me-1"></i> Excluir
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-body">
                <h3><?php echo htmlspecialchars($current_task['title']); ?></h3>
                
                <div class="mb-3">
                    <?php
                    $type_labels = ['task' => 'Tarefa', 'meeting' => 'Reunião', 'appointment' => 'Compromisso'];
                    $priority_labels = ['low' => 'Baixa', 'medium' => 'Média', 'high' => 'Alta', 'urgent' => 'Urgente'];
                    $status_labels = ['pending' => 'Pendente', 'in_progress' => 'Em Progresso', 'completed' => 'Concluída', 'cancelled' => 'Cancelada'];
                    
                    $priority_colors = ['low' => 'secondary', 'medium' => 'primary', 'high' => 'warning', 'urgent' => 'danger'];
                    $status_colors = ['pending' => 'warning', 'in_progress' => 'info', 'completed' => 'success', 'cancelled' => 'secondary'];
                    ?>
                    
                    <span class="badge bg-<?php echo $priority_colors[$current_task['priority']]; ?> me-2">
                        <i class="fas fa-flag me-1"></i><?php echo $priority_labels[$current_task['priority']]; ?>
                    </span>
                    <span class="badge bg-secondary me-2">
                        <?php echo $type_labels[$current_task['type']]; ?>
                    </span>
                    <span class="badge bg-<?php echo $status_colors[$current_task['status']]; ?>">
                        <?php echo $status_labels[$current_task['status']]; ?>
                    </span>
                </div>
                
                <?php if ($current_task['description']): ?>
                <div class="mb-4">
                    <h6>Descrição:</h6>
                    <p><?php echo nl2br(htmlspecialchars($current_task['description'])); ?></p>
                </div>
                <?php endif; ?>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>Atribuído para:</h6>
                        <p><i class="fas fa-user me-2"></i><?php echo htmlspecialchars($current_task['assigned_to_name']); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Atribuído por:</h6>
                        <p><i class="fas fa-user-tie me-2"></i><?php echo htmlspecialchars($current_task['assigned_by_name']); ?></p>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>Vencimento:</h6>
                        <p><i class="fas fa-clock me-2"></i><?php echo date('d/m/Y H:i', strtotime($current_task['due_date'])); ?></p>
                    </div>
                    <?php if ($current_task['completed_at']): ?>
                    <div class="col-md-6">
                        <h6>Concluída em:</h6>
                        <p><i class="fas fa-check me-2"></i><?php echo date('d/m/Y H:i', strtotime($current_task['completed_at'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if ($current_task['notes']): ?>
                <div class="mb-4">
                    <h6>Observações:</h6>
                    <p><?php echo nl2br(htmlspecialchars($current_task['notes'])); ?></p>
                </div>
                <?php endif; ?>
                
                <?php if ($user_id == $current_task['assigned_to']): ?>
                <div class="mb-3">
                    <h6>Atualizar Status:</h6>
                    <form method="post" action="?action=update_status&id=<?php echo $id; ?>" class="d-inline">
                        <select name="status" class="form-select form-select-sm d-inline-block w-auto me-2" onchange="this.form.submit()">
                            <option value="pending" <?php echo $current_task['status'] == 'pending' ? 'selected' : ''; ?>>Pendente</option>
                            <option value="in_progress" <?php echo $current_task['status'] == 'in_progress' ? 'selected' : ''; ?>>Em Progresso</option>
                            <option value="completed" <?php echo $current_task['status'] == 'completed' ? 'selected' : ''; ?>>Concluída</option>
                            <option value="cancelled" <?php echo $current_task['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelada</option>
                        </select>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Comentários -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-comments me-2"></i>Comentários
            </div>
            <div class="card-body">
                <?php foreach ($comments as $c): ?>
                <div class="mb-3 pb-3 border-bottom">
                    <div class="d-flex justify-content-between">
                        <strong><?php echo htmlspecialchars($c['user_name']); ?></strong>
                        <small class="text-muted"><?php echo date('d/m/Y H:i', strtotime($c['created_at'])); ?></small>
                    </div>
                    <p class="mb-0 mt-2"><?php echo nl2br(htmlspecialchars($c['comment'])); ?></p>
                </div>
                <?php endforeach; ?>
                
                <form method="post" action="?action=add_comment&id=<?php echo $id; ?>">
                    <div class="mb-3">
                        <textarea class="form-control" name="comment" rows="3" placeholder="Adicionar comentário..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-1"></i>Enviar Comentário
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <!-- Próximas tarefas -->
        <?php if (!empty($upcoming)): ?>
        <div class="card">
            <div class="card-header">
                <i class="fas fa-clock me-2"></i>Próximas Tarefas
            </div>
            <div class="card-body p-2">
                <?php foreach ($upcoming as $u): ?>
                <div class="p-2 border-bottom">
                    <a href="?action=view&id=<?php echo $u['id']; ?>" class="text-decoration-none">
                        <div class="fw-bold"><?php echo htmlspecialchars($u['title']); ?></div>
                        <small class="text-muted">
                            <i class="fas fa-clock me-1"></i><?php echo date('d/m/Y', strtotime($u['due_date'])); ?>
                        </small>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php endif; ?>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
