<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Diamond System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 0;
        }
        .install-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 40px;
            max-width: 900px;
            margin: 0 auto;
        }
        .step {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .code-block {
            background: #2d3748;
            color: #e2e8f0;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            overflow-x: auto;
        }
        h1 {
            color: #667eea;
            margin-bottom: 30px;
        }
        .badge-info {
            background: #667eea;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="install-card">
            <h1><i class="fas fa-gem"></i> Diamond System - Guia de Instalação</h1>
            <p class="lead">Sistema de Gestão Comercial completo com PHP e MySQL</p>
            
            <div class="alert alert-info">
                <strong><i class="fas fa-info-circle"></i> Informação:</strong> Este sistema foi desenvolvido para rodar em ambiente XAMPP local.
            </div>

            <h3><i class="fas fa-download"></i> Passo 1: Baixar e Instalar o XAMPP</h3>
            <div class="step">
                <p>1. Acesse <a href="https://www.apachefriends.org" target="_blank">https://www.apachefriends.org</a></p>
                <p>2. Baixe a versão mais recente do XAMPP para seu sistema operacional</p>
                <p>3. Instale o XAMPP (recomendado em C:\xampp no Windows)</p>
                <p><span class="badge-info">Requisitos: PHP 7.4+ e MySQL 5.7+</span></p>
            </div>

            <h3><i class="fas fa-folder"></i> Passo 2: Copiar Arquivos do Sistema</h3>
            <div class="step">
                <p>1. Copie a pasta <code>diamond_system</code> para:</p>
                <div class="code-block">C:\xampp\htdocs\diamond_system</div>
                <p>2. Certifique-se de que todos os arquivos estejam na pasta correta</p>
            </div>

            <h3><i class="fas fa-database"></i> Passo 3: Criar o Banco de Dados</h3>
            <div class="step">
                <p>1. Inicie o XAMPP Control Panel</p>
                <p>2. Inicie os serviços <strong>Apache</strong> e <strong>MySQL</strong></p>
                <p>3. Acesse o phpMyAdmin: <a href="http://localhost/phpmyadmin" target="_blank">http://localhost/phpmyadmin</a></p>
                <p>4. Clique em "Importar" ou "SQL"</p>
                <p>5. Copie e cole o conteúdo do arquivo <code>database.sql</code> ou importe o arquivo</p>
                <p>6. Clique em "Executar" para criar o banco de dados</p>
            </div>

            <h3><i class="fas fa-cog"></i> Passo 4: Configurar Conexão</h3>
            <div class="step">
                <p>Verifique as configurações no arquivo <code>config/config.php</code>:</p>
                <div class="code-block">
define('DB_HOST', 'localhost');<br>
define('DB_USER', 'root');<br>
define('DB_PASS', '');<br>
define('DB_NAME', 'diamond_system');<br>
define('BASE_URL', '/diamond_system/');
                </div>
                <p><strong>Nota:</strong> Se seu MySQL tem senha, altere DB_PASS</p>
            </div>

            <h3><i class="fas fa-play"></i> Passo 5: Acessar o Sistema</h3>
            <div class="step">
                <p>1. Abra seu navegador</p>
                <p>2. Acesse: <a href="http://localhost/diamond_system" target="_blank">http://localhost/diamond_system</a></p>
                <p>3. Faça login com as credenciais padrão:</p>
                <div class="code-block">
<strong>Usuário:</strong> admin<br>
<strong>Senha:</strong> admin123
                </div>
                <div class="alert alert-warning mt-3">
                    <strong><i class="fas fa-exclamation-triangle"></i> Importante:</strong> Altere a senha padrão após o primeiro login!
                </div>
            </div>

            <h3><i class="fas fa-check-circle"></i> Funcionalidades do Sistema</h3>
            <div class="step">
                <ul>
                    <li><i class="fas fa-chart-line"></i> Dashboard com estatísticas em tempo real</li>
                    <li><i class="fas fa-shopping-cart"></i> Sistema completo de vendas (PDV)</li>
                    <li><i class="fas fa-gem"></i> Gerenciamento de produtos e estoque</li>
                    <li><i class="fas fa-users"></i> Cadastro de clientes</li>
                    <li><i class="fas fa-tags"></i> Categorização de produtos</li>
                    <li><i class="fas fa-chart-bar"></i> Relatórios detalhados de vendas</li>
                    <li><i class="fas fa-user-shield"></i> Controle de usuários e permissões</li>
                    <li><i class="fas fa-store"></i> Vitrine de produtos</li>
                </ul>
            </div>

            <h3><i class="fas fa-users-cog"></i> Perfis de Usuários</h3>
            <div class="step">
                <p><strong>Administrador:</strong> Acesso total ao sistema</p>
                <p><strong>Gerente:</strong> Gerencia produtos, vendas, clientes e usuários (exceto admins)</p>
                <p><strong>Vendedor:</strong> Registra vendas e clientes (visualiza produtos)</p>
            </div>

            <h3><i class="fas fa-question-circle"></i> Solução de Problemas</h3>
            <div class="step">
                <p><strong>Erro de conexão com banco de dados:</strong></p>
                <ul>
                    <li>Verifique se MySQL está rodando no XAMPP</li>
                    <li>Confirme as credenciais em config/config.php</li>
                    <li>Certifique-se que o banco 'diamond_system' foi criado</li>
                </ul>
                
                <p><strong>Página em branco:</strong></p>
                <ul>
                    <li>Ative display_errors no php.ini do XAMPP</li>
                    <li>Verifique os logs de erro do Apache</li>
                </ul>

                <p><strong>Problemas com upload de imagens:</strong></p>
                <ul>
                    <li>Verifique permissões da pasta assets/uploads/products</li>
                    <li>No Windows, dê permissões de escrita para o usuário</li>
                </ul>
            </div>

            <div class="alert alert-success mt-4">
                <h5><i class="fas fa-rocket"></i> Pronto!</h5>
                <p class="mb-0">Seu sistema Diamond está configurado e pronto para uso. Boas vendas!</p>
            </div>
        </div>
    </div>
</body>
</html>
