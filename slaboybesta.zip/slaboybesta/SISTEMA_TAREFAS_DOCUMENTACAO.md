# 📅 Sistema de Agenda e Tarefas - Diamond System

## 🎯 Visão Geral

O módulo de **Agenda e Tarefas** é uma funcionalidade completa e sofisticada integrada ao Diamond System que permite o gerenciamento hierárquico de tarefas, compromissos e reuniões entre os membros da equipe.

---

## ✨ Funcionalidades Principais

### 1. 📋 Gerenciamento de Tarefas
- **Criação de Tarefas**: Título, descrição, tipo, prioridade e prazo
- **Tipos de Tarefas**:
  - 📝 Tarefa
  - 🤝 Reunião
  - 📅 Compromisso
  
### 2. 🎯 Sistema de Prioridades
- 🔴 **Urgente**: Tarefas críticas que precisam atenção imediata
- 🟠 **Alta**: Tarefas importantes
- 🔵 **Média**: Tarefas normais
- ⚪ **Baixa**: Tarefas que podem esperar

### 3. 📊 Estados de Tarefas
- ⏳ **Pendente**: Tarefa aguardando início
- 🔄 **Em Progresso**: Tarefa sendo executada
- ✅ **Concluída**: Tarefa finalizada
- ❌ **Cancelada**: Tarefa cancelada

### 4. 👥 Hierarquia de Permissões

#### Admin (Administrador)
- ✅ Pode criar tarefas para **Gerentes** e **Vendedores**
- ✅ Visualiza todas as tarefas do sistema
- ✅ Pode editar e excluir qualquer tarefa
- ✅ Acesso completo a todos os recursos

#### Manager (Gerente)
- ✅ Pode criar tarefas apenas para **Vendedores**
- ✅ Visualiza tarefas que criou ou recebeu
- ✅ Pode editar tarefas que criou
- ❌ Não pode criar tarefas para Admins ou outros Gerentes

#### Seller (Vendedor)
- ❌ Não pode criar tarefas para outros usuários
- ✅ Visualiza apenas suas próprias tarefas
- ✅ Pode atualizar o status das tarefas recebidas
- ✅ Pode adicionar comentários

### 5. 📅 Visualizações

#### Minhas Tarefas
- Lista de todas as tarefas atribuídas ao usuário logado
- Ordenadas por prioridade e data de vencimento
- Indicadores visuais de tarefas atrasadas

#### Todas as Tarefas (Admin/Gerente)
- Visão completa de todas as tarefas do sistema
- Filtros por status e prioridade
- Ordenação inteligente

#### Calendário
- Visualização semanal de tarefas
- Seleção de data personalizada
- Tarefas organizadas por dia
- Código de cores por prioridade

### 6. 💬 Sistema de Comentários
- Adicionar comentários em qualquer tarefa
- Histórico completo de comunicação
- Identificação do autor e data/hora

### 7. 🔔 Alertas e Notificações

#### Dashboard
- Widget "Próximas Tarefas" no dashboard principal
- Alerta de tarefas atrasadas em destaque
- Contador de tarefas por status

#### Indicadores Visuais
- 🔴 **Borda Vermelha**: Tarefas atrasadas
- 🟠 **Badge Amarelo**: Tarefas próximas ao vencimento
- ✅ **Badge Verde**: Tarefas concluídas

---

## 🗄️ Estrutura do Banco de Dados

### Tabela: `tasks`
```sql
- id: Identificador único
- title: Título da tarefa
- description: Descrição detalhada
- type: Tipo (task, meeting, appointment)
- priority: Prioridade (low, medium, high, urgent)
- status: Estado atual
- assigned_to: Usuário responsável
- assigned_by: Usuário que criou
- due_date: Data/hora de vencimento
- completed_at: Data/hora de conclusão
- reminder_sent: Flag de lembrete enviado
- notes: Observações adicionais
```

### Tabela: `task_comments`
```sql
- id: Identificador único
- task_id: Referência à tarefa
- user_id: Autor do comentário
- comment: Texto do comentário
- created_at: Data/hora de criação
```

---

## 📂 Arquivos do Sistema

### Arquivos Principais
- **`tasks.php`**: Página principal de gerenciamento
- **`classes/Task.php`**: Classe modelo para lógica de negócios
- **`includes/task_card.php`**: Componente visual de card de tarefa
- **`database_tasks.sql`**: Script de criação das tabelas

### Integração
- **`dashboard.php`**: Widget de tarefas próximas
- **`includes/sidebar.php`**: Menu "Agenda e Tarefas"

---

## 🎨 Design e Interface

### Características Visuais
- **Design Dark Sofisticado**: Seguindo padrão Diamond System
- **Glass-morphism**: Efeitos de vidro translúcido
- **Animações Suaves**: Transições e hover effects
- **Código de Cores Intuitivo**: Por prioridade e status
- **Responsivo**: Funciona em todos os dispositivos

### Componentes
- Cards de tarefas com borda lateral colorida por prioridade
- Badges para tipo, status e prioridade
- Calendário semanal interativo
- Estatísticas visuais no topo

---

## 🚀 Como Usar

### 1. Instalação

Execute o script SQL para criar as tabelas:
```bash
mysql diamond_system < database_tasks.sql
```

### 2. Acessando o Sistema

1. Faça login no Diamond System
2. Acesse **"Agenda e Tarefas"** no menu lateral
3. Escolha a visualização desejada

### 3. Criando uma Tarefa (Admin/Gerente)

1. Clique em **"Nova Tarefa"**
2. Preencha:
   - Título
   - Descrição
   - Tipo (Tarefa/Reunião/Compromisso)
   - Prioridade
   - Atribuir para (usuário)
   - Data e hora de vencimento
   - Observações
3. Clique em **"Salvar Tarefa"**

### 4. Gerenciando Tarefas

#### Como Vendedor:
- Visualize suas tarefas
- Atualize o status (Pendente → Em Progresso → Concluída)
- Adicione comentários

#### Como Gerente:
- Crie tarefas para vendedores
- Acompanhe progresso
- Edite tarefas criadas por você

#### Como Admin:
- Gestão completa
- Visualiza todas as tarefas
- Pode editar/excluir qualquer tarefa

### 5. Visualizando no Dashboard

O dashboard exibe automaticamente:
- **Próximas tarefas** (próximos 7 dias)
- **Tarefas atrasadas** (em destaque)
- **Estatísticas** de tarefas por status

---

## 📊 Estatísticas e Métricas

O sistema rastreia automaticamente:
- **Total de tarefas**
- **Tarefas pendentes**
- **Tarefas em progresso**
- **Tarefas concluídas**
- **Tarefas atrasadas**

---

## 🔐 Segurança

### Validações Implementadas
✅ Verificação de permissões hierárquicas
✅ Proteção contra atribuição não autorizada
✅ Prepared statements (SQL Injection)
✅ Sanitização de inputs
✅ Validação de dados em múltiplas camadas

### Regras de Negócio
- Admin pode atribuir para qualquer um
- Gerente pode atribuir apenas para vendedores
- Vendedor não pode criar tarefas
- Apenas o criador ou admin pode editar/excluir

---

## 🎯 Casos de Uso

### Caso 1: Admin atribuindo tarefa para Gerente
```
Admin: "Revisar estoque de produtos premium"
→ Gerente: Recebe a tarefa com prioridade Alta
→ Gerente: Atualiza status para "Em Progresso"
→ Gerente: Adiciona comentários sobre o progresso
→ Gerente: Marca como "Concluída"
```

### Caso 2: Gerente atribuindo tarefa para Vendedor
```
Gerente: "Fazer follow-up com cliente X"
→ Vendedor: Recebe a tarefa com prioridade Média
→ Vendedor: Vê alerta no dashboard
→ Vendedor: Inicia tarefa
→ Vendedor: Comenta resultado
→ Vendedor: Marca como concluída
```

### Caso 3: Reunião Agendada
```
Admin: Cria "Reunião mensal de equipe"
→ Tipo: Reunião
→ Para: Gerente
→ Data: Próxima segunda, 14:00
→ Sistema: Mostra no calendário
→ Sistema: Alerta 24h antes (se implementado)
```

---

## 💡 Dicas e Boas Práticas

### Para Admins e Gerentes:
1. Use prioridades de forma consistente
2. Adicione descrições claras
3. Defina prazos realistas
4. Acompanhe o progresso via comentários
5. Use o calendário para planejamento semanal

### Para Vendedores:
1. Verifique o dashboard diariamente
2. Atualize o status das tarefas regularmente
3. Comente sobre bloqueios ou dificuldades
4. Priorize tarefas atrasadas
5. Marque como concluída apenas quando finalizada

---

## 🔮 Recursos Futuros Sugeridos

- [ ] Notificações por email
- [ ] Lembretes automáticos 24h antes
- [ ] Anexos em tarefas
- [ ] Tags personalizadas
- [ ] Filtros avançados
- [ ] Exportação de relatórios
- [ ] Integração com Google Calendar
- [ ] Notificações push
- [ ] Tarefas recorrentes
- [ ] Subtarefas

---

## 🐛 Solução de Problemas

### Não consigo criar tarefas
- ✅ Verifique se você é Admin ou Gerente
- ✅ Vendedores não podem criar tarefas

### Não vejo todas as tarefas
- ✅ Vendedores veem apenas suas tarefas
- ✅ Use "Todas as Tarefas" se for Admin/Gerente

### Tabelas não existem
- ✅ Execute o script `database_tasks.sql`
- ✅ Verifique permissões do banco de dados

---

## 📞 Suporte Técnico

Em caso de dúvidas ou problemas:
- Consulte esta documentação
- Verifique as permissões de usuário
- Revise os logs do sistema

---

**Desenvolvido com 💎 para o Diamond System**

**Versão**: 1.0  
**Data**: Outubro 2025  
**Status**: ✅ Totalmente Funcional
