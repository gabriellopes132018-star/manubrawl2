<?php
header('Content-Type: application/json');

$cep = $_GET['cep'] ?? '';
$cep = preg_replace('/[^0-9]/', '', $cep);

if (strlen($cep) != 8) {
    echo json_encode(['erro' => true, 'mensagem' => 'CEP inválido']);
    exit;
}

$url = "https://viacep.com.br/ws/{$cep}/json/";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($response === false || $httpCode != 200) {
    echo json_encode(['erro' => true, 'mensagem' => 'Erro ao consultar CEP']);
    exit;
}

$data = json_decode($response, true);

if (isset($data['erro']) && $data['erro']) {
    echo json_encode(['erro' => true, 'mensagem' => 'CEP não encontrado']);
    exit;
}

echo json_encode($data);
?>
