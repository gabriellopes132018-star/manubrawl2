<?php
require_once 'config/config.php';
require_once 'classes/Product.php';
require_once 'classes/Category.php';

require_login();

$conn = db_connect();
$product = new Product($conn);
$category_obj = new Category($conn);

$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$view_mode = $_GET['view'] ?? 'grid';

$all_products = $product->getVitrineProducts();
$categories = $category_obj->getAll();

$products = $all_products;
if (!empty($search)) {
    $products = array_filter($products, function($p) use ($search) {
        return stripos($p['name'], $search) !== false || 
               stripos($p['description'], $search) !== false;
    });
}

if (!empty($category_filter)) {
    $products = array_filter($products, function($p) use ($category_filter) {
        return $p['category_id'] == $category_filter;
    });
}

$page_title = 'Vitrine';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<style>
:root {
    --primary-blue: #3b82f6;
    --primary-purple: #8b5cf6;
    --gradient-primary: linear-gradient(135deg, #3b82f6, #8b5cf6);
    --gradient-soft: linear-gradient(135deg, rgba(59, 130, 246, 0.08), rgba(139, 92, 246, 0.08));
    --shadow-sm: 0 2px 8px rgba(59, 130, 246, 0.08);
    --shadow-md: 0 8px 24px rgba(59, 130, 246, 0.12);
    --shadow-lg: 0 16px 48px rgba(59, 130, 246, 0.18);
    --shadow-xl: 0 24px 64px rgba(59, 130, 246, 0.25);
    --transition-smooth: cubic-bezier(0.4, 0, 0.2, 1);
}

.vitrine-header {
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.08), rgba(139, 92, 246, 0.08));
    backdrop-filter: blur(20px);
    padding: 32px;
    border-radius: 24px;
    margin-bottom: 32px;
    border: 1px solid rgba(59, 130, 246, 0.15);
    box-shadow: var(--shadow-md);
    position: relative;
    overflow: hidden;
}

.vitrine-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.5), transparent);
}

.search-container {
    position: relative;
}

.search-icon {
    position: absolute;
    left: 20px;
    top: 50%;
    transform: translateY(-50%);
    color: #60a5fa;
    font-size: 18px;
    z-index: 2;
    transition: all 0.3s var(--transition-smooth);
}

.search-input {
    padding: 16px 24px 16px 56px !important;
    background: rgba(59, 130, 246, 0.06) !important;
    border: 2px solid rgba(59, 130, 246, 0.15) !important;
    border-radius: 16px !important;
    color: var(--white-text) !important;
    font-size: 15px;
    font-weight: 500;
    transition: all 0.4s var(--transition-smooth);
    backdrop-filter: blur(10px);
}

.search-input::placeholder {
    color: var(--muted-text);
    opacity: 0.6;
}

.search-input:focus {
    background: rgba(59, 130, 246, 0.1) !important;
    border-color: #3b82f6 !important;
    box-shadow: 0 0 0 6px rgba(59, 130, 246, 0.12) !important;
    transform: translateY(-1px);
}

.search-input:focus + .search-icon {
    color: #3b82f6;
    transform: translateY(-50%) scale(1.1);
}

.filter-select {
    padding: 16px 24px !important;
    background: rgba(59, 130, 246, 0.06) !important;
    border: 2px solid rgba(59, 130, 246, 0.15) !important;
    border-radius: 16px !important;
    color: var(--white-text) !important;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.4s var(--transition-smooth);
    backdrop-filter: blur(10px);
}

.filter-select:focus {
    background: rgba(59, 130, 246, 0.1) !important;
    border-color: #3b82f6 !important;
    box-shadow: 0 0 0 6px rgba(59, 130, 246, 0.12) !important;
    transform: translateY(-1px);
}

.view-toggle {
    display: flex;
    gap: 6px;
    background: rgba(59, 130, 246, 0.06);
    padding: 6px;
    border-radius: 14px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(59, 130, 246, 0.1);
}

.view-btn {
    padding: 12px 20px;
    border: none;
    background: transparent;
    color: var(--muted-text);
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.3s var(--transition-smooth);
    font-size: 16px;
    position: relative;
    overflow: hidden;
}

.view-btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(59, 130, 246, 0.2);
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
}

.view-btn:hover::before {
    width: 100px;
    height: 100px;
}

.view-btn.active {
    background: var(--gradient-primary);
    color: white;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
}

.view-btn:hover:not(.active) {
    background: rgba(59, 130, 246, 0.12);
    color: var(--white-text);
    transform: translateY(-1px);
}

.product-card-vitrine {
    background: linear-gradient(145deg, rgba(15, 20, 35, 0.95), rgba(10, 15, 30, 0.95));
    backdrop-filter: blur(30px);
    border: 1px solid rgba(59, 130, 246, 0.2) !important;
    border-radius: 20px;
    overflow: hidden;
    transition: all 0.5s var(--transition-smooth);
    position: relative;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(59, 130, 246, 0.1) inset;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.product-card-vitrine::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(145deg, rgba(59, 130, 246, 0.15), rgba(139, 92, 246, 0.15));
    opacity: 0;
    transition: opacity 0.5s var(--transition-smooth);
    z-index: 0;
    pointer-events: none;
}

.product-card-vitrine::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.5s var(--transition-smooth);
    pointer-events: none;
}

.product-card-vitrine:hover {
    transform: translateY(-16px) scale(1.03);
    box-shadow: 0 20px 60px rgba(59, 130, 246, 0.3), 0 0 0 2px rgba(59, 130, 246, 0.3) inset;
    border-color: rgba(59, 130, 246, 0.5) !important;
}

.product-card-vitrine:hover::before {
    opacity: 1;
}

.product-card-vitrine:hover::after {
    opacity: 1;
}

.product-image-wrapper {
    position: relative;
    height: 180px;
    overflow: hidden;
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.08), rgba(139, 92, 246, 0.08));
}

.product-vitrine-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.6s var(--transition-smooth);
}

.product-card-vitrine:hover .product-vitrine-img {
    transform: scale(1.15) rotate(2deg);
}

.product-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--muted-text);
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(139, 92, 246, 0.1));
}

.product-placeholder i {
    transition: all 0.6s var(--transition-smooth);
}

.product-card-vitrine:hover .product-placeholder i {
    transform: scale(1.2) rotate(-10deg);
    color: #60a5fa;
}

.product-edit-overlay {
    position: absolute;
    top: 12px;
    left: 12px;
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.4s var(--transition-smooth);
    z-index: 10;
}

.product-card-vitrine:hover .product-edit-overlay {
    opacity: 1;
    transform: translateY(0);
}

.btn-product-edit {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(59, 130, 246, 0.3);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s var(--transition-smooth);
    text-decoration: none;
    font-size: 18px;
}

.btn-product-edit:hover {
    background: var(--gradient-primary);
    border-color: #3b82f6;
    transform: scale(1.1) rotate(5deg);
    color: white;
    box-shadow: 0 8px 24px rgba(59, 130, 246, 0.4);
}

.product-badges {
    position: absolute;
    top: 12px;
    right: 12px;
    display: flex;
    gap: 8px;
    z-index: 10;
}

.badge-stock {
    padding: 8px 16px;
    border-radius: 24px;
    font-size: 13px;
    font-weight: 700;
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s var(--transition-smooth);
}

.badge-stock:hover {
    transform: scale(1.05);
}

.badge-stock-high {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.95), rgba(5, 150, 105, 0.95));
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.badge-stock-medium {
    background: linear-gradient(135deg, rgba(245, 158, 11, 0.95), rgba(217, 119, 6, 0.95));
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.badge-stock-low {
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.95), rgba(220, 38, 38, 0.95));
    color: white;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.product-category {
    font-size: 12px;
    color: #60a5fa;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.product-title {
    font-size: 17px;
    font-weight: 700;
    margin-bottom: 10px;
    color: var(--white-text) !important;
    line-height: 1.3;
    letter-spacing: -0.3px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.product-description {
    font-size: 13px;
    color: var(--muted-text) !important;
    flex: 1;
    margin-bottom: 12px;
    line-height: 1.5;
    opacity: 0.85;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.product-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 18px;
    border-top: 1px solid rgba(59, 130, 246, 0.12);
    margin-top: auto;
}

.product-price {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.price-label {
    font-size: 11px;
    color: var(--muted-text);
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 0.8px;
}

.price-value {
    font-size: 22px;
    font-weight: 900;
    background: var(--gradient-primary);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: -0.5px;
}

.product-status {
    font-size: 13px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 6px;
}

.product-status i {
    font-size: 16px;
}

.list-view .product-card-vitrine {
    display: flex;
    flex-direction: row !important;
}

.list-view .product-image-wrapper {
    width: 280px;
    height: 200px;
    flex-shrink: 0;
}

.list-view .card-body {
    flex: 1;
    padding: 20px !important;
}

.list-view .product-description {
    max-width: 600px;
}

.empty-state-card {
    background: var(--gradient-soft);
    backdrop-filter: blur(20px);
    border: 2px dashed rgba(59, 130, 246, 0.3) !important;
    border-radius: 24px;
    padding: 64px 32px !important;
    text-align: center;
}

.empty-state-icon {
    font-size: 72px;
    background: var(--gradient-primary);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 24px;
    opacity: 0.7;
}

.empty-state-title {
    font-size: 28px;
    font-weight: 800;
    margin-bottom: 12px;
    color: var(--white-text);
}

.empty-state-text {
    font-size: 16px;
    color: var(--muted-text);
    margin-bottom: 32px;
    opacity: 0.8;
}

.btn-clear-filters {
    padding: 14px 32px;
    background: var(--gradient-primary);
    border: none;
    border-radius: 14px;
    color: white;
    font-weight: 700;
    font-size: 15px;
    cursor: pointer;
    transition: all 0.3s var(--transition-smooth);
    box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
}

.btn-clear-filters:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(59, 130, 246, 0.4);
}

.products-count-badge {
    padding: 10px 20px;
    background: var(--gradient-primary);
    border-radius: 14px;
    font-size: 15px;
    font-weight: 700;
    box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
}

@media (max-width: 768px) {
    .vitrine-header {
        padding: 20px;
    }
    
    .product-card-vitrine {
        margin-bottom: 20px;
    }
    
    .list-view .product-card-vitrine {
        flex-direction: column !important;
    }
    
    .list-view .product-image-wrapper {
        width: 100%;
        height: 220px;
    }
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.product-card-vitrine {
    animation: fadeInUp 0.6s var(--transition-smooth) backwards;
}

.product-card-vitrine:nth-child(1) { animation-delay: 0.05s; }
.product-card-vitrine:nth-child(2) { animation-delay: 0.1s; }
.product-card-vitrine:nth-child(3) { animation-delay: 0.15s; }
.product-card-vitrine:nth-child(4) { animation-delay: 0.2s; }
.product-card-vitrine:nth-child(5) { animation-delay: 0.25s; }
.product-card-vitrine:nth-child(6) { animation-delay: 0.3s; }
</style>

<div class="vitrine-header">
    <div class="row align-items-center g-3">
        <div class="col-lg-5">
            <div class="search-container">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" class="form-control search-input" placeholder="Buscar produtos..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-lg-3">
            <select id="categoryFilter" class="form-select filter-select">
                <option value="">Todas as Categorias</option>
                <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['id']; ?>" <?php echo $category_filter == $cat['id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($cat['name']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-lg-2">
            <div class="view-toggle">
                <button class="view-btn <?php echo $view_mode == 'grid' ? 'active' : ''; ?>" onclick="setViewMode('grid')" title="Visualização em Grade">
                    <i class="fas fa-th"></i>
                </button>
                <button class="view-btn <?php echo $view_mode == 'list' ? 'active' : ''; ?>" onclick="setViewMode('list')" title="Visualização em Lista">
                    <i class="fas fa-list"></i>
                </button>
            </div>
        </div>
        <div class="col-lg-2 text-end">
            <span class="badge products-count-badge">
                <?php echo count($products); ?> produtos
            </span>
        </div>
    </div>
</div>

<?php if (empty($products)): ?>
    <div class="card empty-state-card">
        <div class="empty-state-icon">
            <i class="fas fa-box-open"></i>
        </div>
        <h4 class="empty-state-title">Nenhum produto encontrado</h4>
        <p class="empty-state-text">Não há produtos que correspondam aos filtros selecionados.</p>
        <button onclick="clearFilters()" class="btn-clear-filters">
            <i class="fas fa-redo me-2"></i> Limpar Filtros
        </button>
    </div>
<?php else: ?>
    <div class="row g-4 <?php echo $view_mode == 'list' ? 'list-view' : ''; ?>">
        <?php foreach ($products as $prod): ?>
            <div class="col-<?php echo $view_mode == 'list' ? '12' : 'xl-2 col-lg-3 col-md-4'; ?>">
                <div class="card h-100 product-card-vitrine">
                    <div class="product-image-wrapper">
                        <?php if (!empty($prod['image'])): ?>
                            <img src="<?php echo BASE_URL; ?>assets/uploads/products/<?php echo htmlspecialchars($prod['image']); ?>" 
                                 alt="<?php echo htmlspecialchars($prod['name']); ?>" 
                                 class="product-vitrine-img" 
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div class="product-placeholder" style="display: none;">
                                <i class="fas fa-gem fa-4x"></i>
                            </div>
                        <?php else: ?>
                            <div class="product-placeholder">
                                <i class="fas fa-gem fa-4x"></i>
                            </div>
                        <?php endif; ?>

                        <?php if (can_manage_products()): ?>
                        <div class="product-edit-overlay">
                            <a href="products.php?action=edit&id=<?php echo $prod['id']; ?>" class="btn-product-edit" title="Editar Produto">
                                <i class="fas fa-edit"></i>
                            </a>
                        </div>
                        <?php endif; ?>

                        <div class="product-badges">
                            <span class="badge-stock badge-stock-<?php echo $prod['stock'] > 10 ? 'high' : ($prod['stock'] > 5 ? 'medium' : 'low'); ?>">
                                <i class="fas fa-box"></i>
                                <?php echo $prod['stock']; ?>
                            </span>
                        </div>
                    </div>

                    <div class="card-body d-flex flex-column p-3">
                        <span class="product-category">
                            <i class="fas fa-tag"></i>
                            <?php echo htmlspecialchars($prod['category_name'] ?? 'Sem categoria'); ?>
                        </span>
                        <h5 class="product-title">
                            <?php echo htmlspecialchars($prod['name']); ?>
                        </h5>
                        <p class="product-description">
                            <?php 
                            $descricao = $prod['description'] ?? 'Produto de alta qualidade para sua joalheria';
                            echo htmlspecialchars(mb_strlen($descricao) > 100 ? mb_substr($descricao, 0, 100) . '...' : $descricao); 
                            ?>
                        </p>

                        <div class="product-footer">
                            <div class="product-price">
                                <span class="price-label">Preço</span>
                                <span class="price-value"><?php echo format_money($prod['price']); ?></span>
                            </div>
                            <?php if ($prod['stock'] > 0): ?>
                            <div class="product-status">
                                <i class="fas fa-check-circle text-success"></i>
                                <span>Disponível</span>
                            </div>
                            <?php else: ?>
                            <div class="product-status text-warning">
                                <i class="fas fa-exclamation-circle"></i>
                                <span>Esgotado</span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<script>
function applyFilters() {
    const search = document.getElementById('searchInput').value;
    const category = document.getElementById('categoryFilter').value;
    const view = new URLSearchParams(window.location.search).get('view') || 'grid';
    
    let url = 'vitrine.php?view=' + view;
    if (search) url += '&search=' + encodeURIComponent(search);
    if (category) url += '&category=' + category;
    
    window.location.href = url;
}

function setViewMode(mode) {
    const search = document.getElementById('searchInput').value;
    const category = document.getElementById('categoryFilter').value;
    
    let url = 'vitrine.php?view=' + mode;
    if (search) url += '&search=' + encodeURIComponent(search);
    if (category) url += '&category=' + category;
    
    window.location.href = url;
}

function clearFilters() {
    window.location.href = 'vitrine.php';
}

document.getElementById('searchInput').addEventListener('keyup', function(e) {
    if (e.key === 'Enter') {
        applyFilters();
    }
});

document.getElementById('categoryFilter').addEventListener('change', applyFilters);

let searchTimeout;
document.getElementById('searchInput').addEventListener('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(applyFilters, 500);
});
</script>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
